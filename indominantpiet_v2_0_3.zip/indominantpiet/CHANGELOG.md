# CHANGELOG

## 1.2.0

- Add support for Foundry v10

## 2.0.0

-   Indominant system generated from Boilerplate base.
-   Using the 2.0 Indominant Game System Primer

## 2.0.1

-   Compendium player view permissions rectified for drag over.  Base import will not transfer player viewing permissions requiring manual permissions for sub folders.

## 2.0.2

-   Renamed Compendium of Archetypes for easier player use directly from Compendium sections.
-   Changed Actor/Threat views to hover by owner for most. Fixed broken token link

## 2.0.3

-   Changed vision settings for all actors to better support limited lighting.
-   Testing clickable attack and damage rolls with gloop threats
